#ifndef CS370_LAB14_SCENE_H
#define CS370_LAB14_SCENE_H

// Define object dimensions
#define BASE_RADIUS 2.0f
#define BASE_HEIGHT 1.0f
#define LOWER_HEIGHT 4.0f
#define LOWER_WIDTH 2.0f
#define LOWER_DEPTH 1.0f
#define UPPER_HEIGHT 3.0f
#define UPPER_WIDTH 1.0f
#define UPPER_DEPTH 1.0f

#endif //CS370_LAB14_SCENE_H
